import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {MainContentComponent} from
"./main-content/main-content.component";
import {AdminComponent} from "./admin/admin.component";
import { ProductListComponent } from './admin/product-list/product-list.component';
import { AddProductComponent } from './add-product/add-product.component';
import { AboutUsComponent } from './about-us/about-us.component';

const routes:Routes = [
  {path: "", redirectTo: '/home', pathMatch: 'full'},
  {path: "home", component: MainContentComponent},
  {path: "addproduct", component: AddProductComponent},
  {path: "about", component: AboutUsComponent},
  {path: "admin", component: AdminComponent,
children:[{path:"products", component:ProductListComponent},
]}
 ];


@NgModule({
  imports: [RouterModule. forRoot(routes)],
  exports: [RouterModule]
  })
export class AppRoutingModule { }
