import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductsService } from 'src/app/products.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products:Product[];
  constructor(private productsService:ProductsService) { }

  ngOnInit(){
    this.productsService.getProducts().subscribe(products => {
    this.products = products;}); 
  

}
}
