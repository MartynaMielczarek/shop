import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MainContentComponent } from './main-content/main-content.component';
import { ProductsComponent } from './main-content/products/products.component';
import { ProductComponent } from './main-content/products/product/product.component';
import {AdminComponent} from './admin/admin.component';
import { AppRoutingModule } from './app-routing.module';
import { ProductListComponent } from './admin/product-list/product-list.component';
import { AddProductComponent } from './add-product/add-product.component';
import { AboutUsComponent } from './about-us/about-us.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainContentComponent,
    ProductComponent,
    ProductsComponent,
    ProductListComponent,
    AdminComponent,
    AddProductComponent,
    AboutUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
