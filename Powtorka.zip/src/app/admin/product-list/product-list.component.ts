import { Component, OnInit } from '@angular/core';
import {ProductsService} from 'src/app/products.service';
import {Product} from 'src/app/product'

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  productList: Product[];

  constructor(private productService:ProductsService) { }

  ngOnInit() {
    this.productService.getProducts().subscribe(products => {
      this.productList = products;
    });
  }

  delete(product){
    const index = this.productList.indexOf(product);
    this.productList.splice(index, 1);
}

inc(product) {
  const index = this.productList.indexOf(product);
  this.productList[index].amount++;
}

dec(product) {
  const index = this.productList.indexOf(product);
  this.productList[index].amount--;
}

}






