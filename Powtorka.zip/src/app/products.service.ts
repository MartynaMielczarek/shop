import { Injectable } from '@angular/core';
import { Product } from './product';
import { Observable, of } from 'rxjs';
import { mapTo, delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  private products :Product[];


  constructor() {
  this.products = [
    {number: 1, name: 'Grabki', price: 20, vat: 23, amount: 50},
    {number: 2, name: 'Łopatka', price: 60, vat: 23, amount: 15},
    {number: 3, name: 'Doniczka', price: 15, vat: 23, amount: 40}
  ];}

  getProducts():Observable<Product[]>{
    return of (this.products).pipe(delay(0));
  }

  getProductByNumber(number: number): Product {
    return this.products.find(product => product.number === number);
  }


}
