export class Product {
    number: number;
    name: string;
    price: number;
    vat:number;
    amount:number;


    constructor(number: number, name: string, price: number, vat: number, amount: number) {
        this.number=number;
        this.name=name;
        this.price=price;
        this.vat=vat;
        this.amount=amount;
      }



}